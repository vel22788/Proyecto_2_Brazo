/*
 * PMW0.h
 *
 * Created: 13/04/2024 19:17:49
 *  Author: angel
 */ 


#ifndef PWM2_H_
#define PWM2_H_
#include <stdint.h>
#include <avr/io.h>

void init_PMW2A(int orientacion,int modo,int preescaler);
void init_PMW2B(int orientacion);
void duty_cycle2A(int duty);
void duty_cycle2B(int duty);

#endif /* PWM2_H_ */