/*
 * Timer1.h
 *
 * Created: 16/04/2024 23:02:27
 *  Author: angel
 */ 


#ifndef TIMER0_H_
#define TIMER0_H_

#include <stdint.h>
#include <avr/io.h>

void init_Timer1(int modo, int preescaler);
void CTC_Timer1A(uint16_t valor);
void CTC_Timer1B(uint16_t valor);





#endif /* TIMER1_H_ */